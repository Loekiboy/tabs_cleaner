# Web Page Cleaner

A small Chrome/Edge extension that uses [Gemini](https://gemini.google.com/) to automatically decide which tabs to close based on a natural-language description.

## What it does
- Collects metadata from all open tabs (title, URL, pinned/active/audible/incognito status, etc.)
- Sends that list plus your request to Gemini
- Gemini returns a strict JSON array describing which tabs to close
- The extension automatically closes those tabs and shows you what was closed

> **Important**: The extension opens a background Gemini tab and closes it automatically when the response arrives.

## How to use

De extensie werkt momenteel op zowel **Chrome/Edge** als **Firefox**.

### Installatie via .zip (Aanbevolen voor Chrome/Edge/Firefox)
Aangezien Chrome externe `.crx` bestanden vaak blokkeert, is de makkelijkste methode om de `.zip` in te laden (of de folder lokaal te gebruiken):
1. Download of clone deze map (of download het `tabs_cleaner.zip` bestand).
2. **Chrome/Edge**: 
   - Ga naar `chrome://extensions/` of `edge://extensions/`
   - Zet **Developer mode** (Ontwikkelaarsmodus) rechtsboven aan.
   - Klik op **Load unpacked** (Uitgepakte extensie laden) en selecteer de uitgepakte map.
3. **Firefox**:
   - Ga naar `about:debugging#/runtime/this-firefox`
   - Klik op **Load Temporary Add-on...**
   - Selecteer het `manifest.json` bestand of de `tabs_cleaner.zip`.

### Installatie via .crx (Alleen voor geavanceerde gebruikers)
*Let op: Chrome staat het vaak niet toe om direct `.crx` bestanden te installeren buiten de store, tenzij je speciale 'policies' hebt of een op Chromium gebaseerde browser gebruikt.*
1. Ga naar `chrome://extensions/` en zorg dat **Developer mode** aan staat.
2. Sleep het gegenereerde `.crx` bestand direct in dit venster om te installeren.
*(Je kunt zelf een `.crx` genereren door in `chrome://extensions/` op **Pack extension** te klikken en deze map te selecteren.)*

### Extensie gebruiken
1. Klik op het extensie-icoontje naast je adresbalk om de popup te openen.
2. Beschrijf wat je wilt verwijderen (bijv. "sluit alle nieuws tabbladen" of "sluit tabbladen die ik al een uur niet heb gebruikt").
3. De extensie laadt een verborgen Gemini-tabblad en sluit daarna automatisch de geselecteerde tabs.

## 🧠 What Gemini sees (in the prompt)
The extension sends Gemini a list of all open tabs including:
- Title + URL
- Whether the tab is pinned, active, audible, discarded, or incognito
- Tab group ID (if any)
- Tab status (loading/complete/unknown)
- Last accessed timestamp

## 🛠️ Files in the project
- `manifest.json` – extension metadata and permissions
- `popup.html` + `popup.js` – UI and tab collection logic
- `background.js` – handles opening Gemini and closing it when done
- `content.js` – injects the prompt into Gemini and scrapes the response
- `icons/` – generated 16/48/128 PNG icons (from `icon.svg`)

## Permissions
The extension requests:
- `tabs` (to read and close tabs)
- `activeTab` (to get current tab info)
- `scripting` (used by content script injection)
- `storage` (to pass data between popup, background, and content scripts)

## Notes
- Gemini must be logged in for the extension to work.
- This is an experimental workflow; Gemini’s interpretation may vary.

---

If you want the extension to stop asking Gemini and instead use a local ruleset (e.g., close tabs older than X hours), I can add that too.